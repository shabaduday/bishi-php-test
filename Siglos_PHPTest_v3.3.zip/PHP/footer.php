<!-- Footer -->
<footer class="footer">
			<div class="container">
					<div class="d-flex justify-content-center align-items-center">
							<a href="#" class="cta-button">BOOK AN APPOINTMENT</a>
							<span class="or-text">OR</span>
							<a href="tel:888-989-8758" class="cta-phone">CALL-888-989-8758</a>
					</div>
			</div>
	</footer>